# Psiphon pro for Android Termux


### စတင်ရန်  

pkg update                                   
pkg upgrade -y                            
pkg install git                         
pkg install golang

### clone ပါ 

git clone https://github.com/victorgeel/Yes.git 

cd Yes                         

chmod +x *       

### vpn စ ရန် 

for old version 

./yes

or

for my one

./psp

## Region ( for Asian region recommend to use SG & JP )

❤️‍🔥eg cmd

💟For s'pore

./yes -r SG

💟For japan

./yes -r JP

### Proxy setting

127.0.0.1
port 9693

## Enjoy 💗


## Update
💚You can choose two versions here💚

🍭If u like to use old Brainfuck version type cmd

./yes

🍭If u like to use modified version of mine type cmd

./psp


